import re, json
from flask import Flask, render_template, request

d = {}
def dicti():
    global d
    f = open(r'C:\Users\student\Desktop\raw.txt', 'r', encoding = 'utf-8')
    text = f.readlines()
    d = {}
    for line in text:
        if 'lex:' in line:
            word = line[6:].replace('\n', '')
        elif 'gramm:' in line:
            d[word] = []
            d[word].append(line[8:].replace('\n', ''))
        elif 'trans_ru:' in line:
            d[word].append(line[11:].replace('\n', ''))
    return d
def udmd(d):
    di = json.dumps(d, indent = 2, ensure_ascii = False)
    f = open('udmudict.txt', 'w', encoding = 'utf-8')
    f.write(di)
def rusd(d):
    di = {}
    for k in d:
        newkeys = re.split('(, ?|\d\. )', d[k][1])
        for i,el in enumerate(newkeys):
            newkeys[i] = re.sub('(,|\d\. )', '', el)
        for el in newkeys:
            if el != '' and el != ' ':
                if el in di:
                    di[el.strip(' ')].append((d[k][0], k))
                else:
                    di[el.strip(' ')] = [(d[k][0], k)]
                    
    di = json.dumps(di, indent = 2, ensure_ascii = False)
    f = open('rusdict.txt', 'w', encoding = 'utf-8')
    f.write(di)


def main():
    d = dicti()
    udmd(d)
    rusd(d)
    
main()

app = Flask(__name__)

@app.route('/')
def pagem():
    global d
    if request.args:
        for k in d:
            if request.args['word'] == k:
                result = d[k][1]
                word = k
        return render_template('res.html', word = word, result = result)
    else:
        return render_template('mainp.html')

if __name__ == '__main__':
    app.run(debug = True)

    
